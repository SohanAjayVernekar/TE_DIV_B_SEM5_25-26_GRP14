import { redirect, notFound } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { UserProfile } from "@/components/user-profile"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface ProfilePageProps {
  params: {
    userId: string
  }
}

export default async function UserProfilePage({ params }: ProfilePageProps) {
  const supabase = await createClient()

  const {
    data: { user: currentUser },
    error,
  } = await supabase.auth.getUser()

  if (error || !currentUser) {
    redirect("/auth/login")
  }

  // Get the profile of the user being viewed
  const { data: profile, error: profileError } = await supabase
    .from("profiles")
    .select("*")
    .eq("id", params.userId)
    .single()

  if (profileError || !profile) {
    notFound()
  }

  // Check if there's an existing chat between current user and this user
  const { data: existingChat } = await supabase
    .from("chats")
    .select("id")
    .or(
      `and(user1_id.eq.${currentUser.id},user2_id.eq.${params.userId}),and(user1_id.eq.${params.userId},user2_id.eq.${currentUser.id})`,
    )
    .single()

  const isOwnProfile = currentUser.id === params.userId

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 dark:from-gray-900 dark:to-gray-800">
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <Button asChild variant="ghost" size="sm">
              <Link href="/chat" className="flex items-center gap-2 text-gray-600 hover:text-gray-900">
                <ArrowLeft className="w-4 h-4" />
                Back to Chat
              </Link>
            </Button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900 dark:text-white">
                {isOwnProfile ? "Your Profile" : `${profile.display_name || "User"}'s Profile`}
              </h1>
              <p className="text-gray-600 dark:text-gray-300">
                {isOwnProfile ? "This is how others see your profile" : "View user information"}
              </p>
            </div>
          </div>

          {/* User Profile */}
          <UserProfile
            profile={profile}
            isOwnProfile={isOwnProfile}
            currentUserId={currentUser.id}
            existingChatId={existingChat?.id}
          />
        </div>
      </div>
    </div>
  )
}
