"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Plus, Search } from "lucide-react"
import { cn } from "@/lib/utils"

interface Profile {
  id: string
  display_name: string | null
  avatar_url: string | null
  bio: string | null
}

interface Chat {
  id: string
  user1_id: string
  user2_id: string
  updated_at: string
  user1: Profile
  user2: Profile
}

interface ChatSidebarProps {
  chats: Chat[]
  allUsers: Profile[]
  currentUserId: string
  selectedChatId: string | null
  onChatSelect: (chatId: string) => void
  onStartNewChat: (userId: string) => void
  onlineUsers: Set<string>
}

export function ChatSidebar({
  chats,
  allUsers,
  currentUserId,
  selectedChatId,
  onChatSelect,
  onStartNewChat,
  onlineUsers,
}: ChatSidebarProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [isNewChatOpen, setIsNewChatOpen] = useState(false)

  const filteredUsers = allUsers.filter((user) => user.display_name?.toLowerCase().includes(searchQuery.toLowerCase()))

  const getOtherUser = (chat: Chat) => {
    return chat.user1_id === currentUserId ? chat.user2 : chat.user1
  }

  const getInitials = (name: string | null) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const formatTime = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInHours = (now.getTime() - date.getTime()) / (1000 * 60 * 60)

    if (diffInHours < 24) {
      return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
    } else if (diffInHours < 168) {
      return date.toLocaleDateString([], { weekday: "short" })
    } else {
      return date.toLocaleDateString([], { month: "short", day: "numeric" })
    }
  }

  const isUserOnline = (userId: string) => {
    return onlineUsers.has(userId)
  }

  return (
    <div className="flex flex-col h-full">
      {/* Header */}
      <div className="p-4 border-b border-gray-200 dark:border-gray-700">
        <div className="flex items-center justify-between mb-3">
          <h2 className="font-semibold text-gray-900 dark:text-white">Messages</h2>
          <Dialog open={isNewChatOpen} onOpenChange={setIsNewChatOpen}>
            <DialogTrigger asChild>
              <Button size="sm" className="bg-blue-600 hover:bg-blue-700 text-white">
                <Plus className="w-4 h-4" />
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Start New Chat</DialogTitle>
              </DialogHeader>
              <div className="space-y-4">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Search users..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <ScrollArea className="h-60">
                  <div className="space-y-2">
                    {filteredUsers.map((user) => (
                      <div
                        key={user.id}
                        className="flex items-center gap-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                        onClick={() => {
                          onStartNewChat(user.id)
                          setIsNewChatOpen(false)
                          setSearchQuery("")
                        }}
                      >
                        <div className="relative">
                          <Avatar className="w-8 h-8">
                            <AvatarImage src={user.avatar_url || ""} />
                            <AvatarFallback className="bg-blue-100 text-blue-600 text-xs">
                              {getInitials(user.display_name)}
                            </AvatarFallback>
                          </Avatar>
                          {isUserOnline(user.id) && (
                            <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-800 rounded-full"></span>
                          )}
                        </div>
                        <div className="flex-1">
                          <span className="text-sm font-medium text-gray-900 dark:text-white">
                            {user.display_name || "Unknown User"}
                          </span>
                          {isUserOnline(user.id) && (
                            <p className="text-xs text-green-600 dark:text-green-400">Online</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </ScrollArea>
              </div>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      {/* Chat List */}
      <ScrollArea className="flex-1">
        <div className="p-2">
          {chats.length === 0 ? (
            <div className="text-center py-8 text-gray-500 dark:text-gray-400">
              <p className="text-sm">No conversations yet</p>
              <p className="text-xs mt-1">Start a new chat to begin messaging</p>
            </div>
          ) : (
            <div className="space-y-1">
              {chats.map((chat) => {
                const otherUser = getOtherUser(chat)
                const isSelected = selectedChatId === chat.id

                return (
                  <div
                    key={chat.id}
                    className={cn(
                      "flex items-center gap-3 p-3 rounded-lg cursor-pointer transition-colors",
                      isSelected
                        ? "bg-blue-100 dark:bg-blue-900/30 border border-blue-200 dark:border-blue-800"
                        : "hover:bg-gray-100 dark:hover:bg-gray-700",
                    )}
                    onClick={() => onChatSelect(chat.id)}
                  >
                    <div className="relative">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={otherUser.avatar_url || ""} />
                        <AvatarFallback className="bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300">
                          {getInitials(otherUser.display_name)}
                        </AvatarFallback>
                      </Avatar>
                      {isUserOnline(otherUser.id) && (
                        <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-800 rounded-full"></span>
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between">
                        <p className="font-medium text-gray-900 dark:text-white truncate">
                          {otherUser.display_name || "Unknown User"}
                        </p>
                        <span className="text-xs text-gray-500 dark:text-gray-400">{formatTime(chat.updated_at)}</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <p className="text-sm text-gray-500 dark:text-gray-400 truncate">
                          {isUserOnline(otherUser.id) ? "Online" : "Click to start messaging"}
                        </p>
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </ScrollArea>
    </div>
  )
}
