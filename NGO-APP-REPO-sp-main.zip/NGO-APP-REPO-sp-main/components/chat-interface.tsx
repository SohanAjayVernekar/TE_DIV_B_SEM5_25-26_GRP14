"use client"

import { useState, useEffect } from "react"
import type { User } from "@supabase/supabase-js"
import { ChatSidebar } from "./chat-sidebar"
import { ChatWindow } from "./chat-window"
import { Button } from "@/components/ui/button"
import { LogOut, UserIcon, Settings } from "lucide-react"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import Link from "next/link"

interface Profile {
  id: string
  display_name: string | null
  avatar_url: string | null
  bio: string | null
}

interface Chat {
  id: string
  user1_id: string
  user2_id: string
  updated_at: string
  user1: Profile
  user2: Profile
}

interface Message {
  id: string
  chat_id: string
  sender_id: string
  content: string
  created_at: string
}

interface ChatInterfaceProps {
  currentUser: User
  currentProfile: Profile | null
  chats: Chat[]
  allUsers: Profile[]
}

export function ChatInterface({ currentUser, currentProfile, chats, allUsers }: ChatInterfaceProps) {
  const [selectedChatId, setSelectedChatId] = useState<string | null>(null)
  const [messages, setMessages] = useState<Message[]>([])
  const [isLoadingMessages, setIsLoadingMessages] = useState(false)
  const [realtimeChats, setRealtimeChats] = useState<Chat[]>(chats)
  const [onlineUsers, setOnlineUsers] = useState<Set<string>>(new Set())
  const router = useRouter()
  const supabase = createClient()

  const selectedChat = realtimeChats.find((chat) => chat.id === selectedChatId)

  useEffect(() => {
    if (!selectedChatId) return

    console.log("[v0] Setting up real-time subscription for chat:", selectedChatId)

    const messagesSubscription = supabase
      .channel(`messages:${selectedChatId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `chat_id=eq.${selectedChatId}`,
        },
        (payload) => {
          console.log("[v0] New message received:", payload.new)
          const newMessage = payload.new as Message
          setMessages((prev) => {
            if (prev.some((msg) => msg.id === newMessage.id)) return prev
            return [...prev, newMessage]
          })
        },
      )
      .subscribe()

    return () => {
      console.log("[v0] Cleaning up message subscription")
      supabase.removeChannel(messagesSubscription)
    }
  }, [selectedChatId, supabase])

  useEffect(() => {
    console.log("[v0] Setting up presence tracking")

    const presenceChannel = supabase.channel("online-users", {
      config: {
        presence: {
          key: currentUser.id,
        },
      },
    })

    presenceChannel
      .on("presence", { event: "sync" }, () => {
        const newState = presenceChannel.presenceState()
        const onlineUserIds = new Set(Object.keys(newState))
        console.log("[v0] Online users updated:", onlineUserIds)
        setOnlineUsers(onlineUserIds)
      })
      .on("presence", { event: "join" }, ({ key }) => {
        console.log("[v0] User joined:", key)
        setOnlineUsers((prev) => new Set([...prev, key]))
      })
      .on("presence", { event: "leave" }, ({ key }) => {
        console.log("[v0] User left:", key)
        setOnlineUsers((prev) => {
          const newSet = new Set(prev)
          newSet.delete(key)
          return newSet
        })
      })
      .subscribe(async (status) => {
        if (status === "SUBSCRIBED") {
          await presenceChannel.track({
            user_id: currentUser.id,
            display_name: currentProfile?.display_name || currentUser.email,
            online_at: new Date().toISOString(),
          })
        }
      })

    return () => {
      console.log("[v0] Cleaning up presence tracking")
      supabase.removeChannel(presenceChannel)
    }
  }, [currentUser.id, currentProfile?.display_name, currentUser.email, supabase])

  useEffect(() => {
    console.log("[v0] Setting up chat updates subscription")

    const chatsSubscription = supabase
      .channel("chats-updates")
      .on(
        "postgres_changes",
        {
          event: "UPDATE",
          schema: "public",
          table: "chats",
        },
        (payload) => {
          console.log("[v0] Chat updated:", payload.new)
          const updatedChat = payload.new as any
          setRealtimeChats((prev) =>
            prev
              .map((chat) => (chat.id === updatedChat.id ? { ...chat, updated_at: updatedChat.updated_at } : chat))
              .sort((a, b) => new Date(b.updated_at).getTime() - new Date(a.updated_at).getTime()),
          )
        },
      )
      .subscribe()

    return () => {
      console.log("[v0] Cleaning up chats subscription")
      supabase.removeChannel(chatsSubscription)
    }
  }, [supabase])

  const handleSignOut = async () => {
    await supabase.auth.signOut()
    router.push("/")
  }

  const loadMessages = async (chatId: string) => {
    setIsLoadingMessages(true)
    try {
      const { data, error } = await supabase
        .from("messages")
        .select("*")
        .eq("chat_id", chatId)
        .order("created_at", { ascending: true })

      if (error) throw error
      setMessages(data || [])
    } catch (error) {
      console.error("Error loading messages:", error)
    } finally {
      setIsLoadingMessages(false)
    }
  }

  const handleChatSelect = (chatId: string) => {
    setSelectedChatId(chatId)
    loadMessages(chatId)
  }

  const handleSendMessage = async (content: string) => {
    if (!selectedChatId || !content.trim()) return

    try {
      const { data, error } = await supabase
        .from("messages")
        .insert({
          chat_id: selectedChatId,
          sender_id: currentUser.id,
          content: content.trim(),
        })
        .select()
        .single()

      if (error) throw error

      await supabase.from("chats").update({ updated_at: new Date().toISOString() }).eq("id", selectedChatId)
    } catch (error) {
      console.error("Error sending message:", error)
    }
  }

  const handleStartNewChat = async (userId: string) => {
    try {
      const { data: existingChat } = await supabase
        .from("chats")
        .select("id")
        .or(
          `and(user1_id.eq.${currentUser.id},user2_id.eq.${userId}),and(user1_id.eq.${userId},user2_id.eq.${currentUser.id})`,
        )
        .single()

      if (existingChat) {
        setSelectedChatId(existingChat.id)
        loadMessages(existingChat.id)
        return
      }

      const { data, error } = await supabase
        .from("chats")
        .insert({
          user1_id: currentUser.id,
          user2_id: userId,
        })
        .select()
        .single()

      if (error) throw error

      router.refresh()
    } catch (error) {
      console.error("Error starting new chat:", error)
    }
  }

  return (
    <div className="flex h-screen bg-gray-50 dark:bg-gray-900">
      {/* Header */}
      <div className="absolute top-0 left-0 right-0 z-10 bg-white dark:bg-gray-800 border-b border-gray-200 dark:border-gray-700 px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 bg-blue-600 rounded-full flex items-center justify-center">
              <UserIcon className="w-4 h-4 text-white" />
            </div>
            <div>
              <h1 className="font-semibold text-gray-900 dark:text-white">ChatApp</h1>
              <p className="text-sm text-gray-500 dark:text-gray-400">
                {currentProfile?.display_name || currentUser.email}
                <span className="ml-2 inline-flex items-center">
                  <span className="w-2 h-2 bg-green-500 rounded-full"></span>
                  <span className="ml-1 text-xs">Online</span>
                </span>
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button asChild variant="ghost" size="sm">
              <Link href="/profile" className="text-gray-500 hover:text-gray-700">
                <Settings className="w-4 h-4" />
              </Link>
            </Button>
            <Button variant="ghost" size="sm" onClick={handleSignOut} className="text-gray-500 hover:text-gray-700">
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex w-full pt-16">
        {/* Sidebar */}
        <div className="w-80 border-r border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800">
          <ChatSidebar
            chats={realtimeChats}
            allUsers={allUsers}
            currentUserId={currentUser.id}
            selectedChatId={selectedChatId}
            onChatSelect={handleChatSelect}
            onStartNewChat={handleStartNewChat}
            onlineUsers={onlineUsers}
          />
        </div>

        {/* Chat Window */}
        <div className="flex-1">
          <ChatWindow
            selectedChat={selectedChat}
            messages={messages}
            currentUserId={currentUser.id}
            isLoadingMessages={isLoadingMessages}
            onSendMessage={handleSendMessage}
            onlineUsers={onlineUsers}
          />
        </div>
      </div>
    </div>
  )
}
