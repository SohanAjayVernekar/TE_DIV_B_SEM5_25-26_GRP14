"use client"

import type React from "react"

import { useState, useRef, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, MessageCircle } from "lucide-react"
import { cn } from "@/lib/utils"

interface Profile {
  id: string
  display_name: string | null
  avatar_url: string | null
  bio: string | null
}

interface Chat {
  id: string
  user1_id: string
  user2_id: string
  updated_at: string
  user1: Profile
  user2: Profile
}

interface Message {
  id: string
  chat_id: string
  sender_id: string
  content: string
  created_at: string
}

interface ChatWindowProps {
  selectedChat: Chat | undefined
  messages: Message[]
  currentUserId: string
  isLoadingMessages: boolean
  onSendMessage: (content: string) => void
  onlineUsers: Set<string>
}

export function ChatWindow({
  selectedChat,
  messages,
  currentUserId,
  isLoadingMessages,
  onSendMessage,
  onlineUsers,
}: ChatWindowProps) {
  const [newMessage, setNewMessage] = useState("")
  const scrollAreaRef = useRef<HTMLDivElement>(null)
  const messagesEndRef = useRef<HTMLDivElement>(null)

  const getOtherUser = (chat: Chat) => {
    return chat.user1_id === currentUserId ? chat.user2 : chat.user1
  }

  const getInitials = (name: string | null) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const formatMessageTime = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
  }

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!newMessage.trim()) return

    onSendMessage(newMessage)
    setNewMessage("")
  }

  const isUserOnline = (userId: string) => {
    return onlineUsers.has(userId)
  }

  // Auto-scroll to bottom when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages])

  if (!selectedChat) {
    return (
      <div className="flex-1 flex items-center justify-center bg-gray-50 dark:bg-gray-900">
        <div className="text-center">
          <MessageCircle className="w-16 h-16 text-gray-300 dark:text-gray-600 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 dark:text-white mb-2">No chat selected</h3>
          <p className="text-gray-500 dark:text-gray-400">Choose a conversation from the sidebar to start messaging</p>
        </div>
      </div>
    )
  }

  const otherUser = getOtherUser(selectedChat)

  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-900">
      {/* Chat Header */}
      <div className="border-b border-gray-200 dark:border-gray-700 p-4">
        <div className="flex items-center gap-3">
          <div className="relative">
            <Avatar className="w-10 h-10">
              <AvatarImage src={otherUser.avatar_url || ""} />
              <AvatarFallback className="bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300">
                {getInitials(otherUser.display_name)}
              </AvatarFallback>
            </Avatar>
            {isUserOnline(otherUser.id) && (
              <span className="absolute -bottom-0.5 -right-0.5 w-3 h-3 bg-green-500 border-2 border-white dark:border-gray-900 rounded-full"></span>
            )}
          </div>
          <div>
            <h3 className="font-semibold text-gray-900 dark:text-white">{otherUser.display_name || "Unknown User"}</h3>
            <p className="text-sm text-gray-500 dark:text-gray-400">
              {isUserOnline(otherUser.id) ? (
                <span className="text-green-600 dark:text-green-400">Online</span>
              ) : (
                "Offline"
              )}
            </p>
          </div>
        </div>
      </div>

      {/* Messages */}
      <ScrollArea className="flex-1 p-4" ref={scrollAreaRef}>
        {isLoadingMessages ? (
          <div className="flex items-center justify-center h-32">
            <div className="text-gray-500 dark:text-gray-400">Loading messages...</div>
          </div>
        ) : messages.length === 0 ? (
          <div className="flex items-center justify-center h-32">
            <div className="text-center">
              <p className="text-gray-500 dark:text-gray-400">No messages yet</p>
              <p className="text-sm text-gray-400 dark:text-gray-500 mt-1">Send a message to start the conversation</p>
            </div>
          </div>
        ) : (
          <div className="space-y-4">
            {messages.map((message) => {
              const isOwnMessage = message.sender_id === currentUserId

              return (
                <div key={message.id} className={cn("flex", isOwnMessage ? "justify-end" : "justify-start")}>
                  <div
                    className={cn("flex gap-2 max-w-xs lg:max-w-md", isOwnMessage ? "flex-row-reverse" : "flex-row")}
                  >
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={isOwnMessage ? "" : otherUser.avatar_url || ""} />
                      <AvatarFallback className="bg-gray-200 dark:bg-gray-600 text-gray-700 dark:text-gray-300 text-xs">
                        {isOwnMessage ? "You" : getInitials(otherUser.display_name)}
                      </AvatarFallback>
                    </Avatar>
                    <div
                      className={cn(
                        "rounded-lg px-3 py-2",
                        isOwnMessage
                          ? "bg-blue-600 text-white"
                          : "bg-gray-100 dark:bg-gray-700 text-gray-900 dark:text-white",
                      )}
                    >
                      <p className="text-sm">{message.content}</p>
                      <p
                        className={cn(
                          "text-xs mt-1",
                          isOwnMessage ? "text-blue-100" : "text-gray-500 dark:text-gray-400",
                        )}
                      >
                        {formatMessageTime(message.created_at)}
                      </p>
                    </div>
                  </div>
                </div>
              )
            })}
            <div ref={messagesEndRef} />
          </div>
        )}
      </ScrollArea>

      {/* Message Input */}
      <div className="border-t border-gray-200 dark:border-gray-700 p-4">
        <form onSubmit={handleSendMessage} className="flex gap-2">
          <Input
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            placeholder="Type a message..."
            className="flex-1"
          />
          <Button type="submit" disabled={!newMessage.trim()} className="bg-blue-600 hover:bg-blue-700 text-white">
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  )
}
