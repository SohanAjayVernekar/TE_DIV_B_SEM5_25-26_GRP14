"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { createClient } from "@/lib/supabase/client"
import { useRouter } from "next/navigation"
import { MessageCircle, Settings, Calendar } from "lucide-react"
import Link from "next/link"

interface Profile {
  id: string
  display_name: string | null
  avatar_url: string | null
  bio: string | null
  created_at: string
  updated_at: string
}

interface UserProfileProps {
  profile: Profile
  isOwnProfile: boolean
  currentUserId: string
  existingChatId?: string
}

export function UserProfile({ profile, isOwnProfile, currentUserId, existingChatId }: UserProfileProps) {
  const [isStartingChat, setIsStartingChat] = useState(false)
  const router = useRouter()
  const supabase = createClient()

  const getInitials = (name: string | null) => {
    if (!name) return "U"
    return name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2)
  }

  const formatJoinDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleDateString("en-US", { year: "numeric", month: "long" })
  }

  const handleStartChat = async () => {
    if (existingChatId) {
      router.push(`/chat?chatId=${existingChatId}`)
      return
    }

    setIsStartingChat(true)
    try {
      // Create new chat
      const { data, error } = await supabase
        .from("chats")
        .insert({
          user1_id: currentUserId,
          user2_id: profile.id,
        })
        .select()
        .single()

      if (error) throw error

      router.push(`/chat?chatId=${data.id}`)
    } catch (error) {
      console.error("Error starting chat:", error)
    } finally {
      setIsStartingChat(false)
    }
  }

  return (
    <div className="space-y-6">
      {/* Main Profile Card */}
      <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <CardHeader className="text-center">
          <div className="flex flex-col items-center gap-4">
            <Avatar className="w-24 h-24">
              <AvatarImage src={profile.avatar_url || ""} />
              <AvatarFallback className="bg-blue-100 text-blue-600 text-2xl">
                {getInitials(profile.display_name)}
              </AvatarFallback>
            </Avatar>
            <div>
              <CardTitle className="text-2xl text-gray-900 dark:text-white">
                {profile.display_name || "Unknown User"}
              </CardTitle>
              <CardDescription className="text-gray-600 dark:text-gray-300 flex items-center gap-2 mt-2">
                <Calendar className="w-4 h-4" />
                Joined {formatJoinDate(profile.created_at)}
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {/* Bio Section */}
          {profile.bio && (
            <div className="mb-6">
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">About</h3>
              <p className="text-gray-600 dark:text-gray-300 leading-relaxed">{profile.bio}</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="flex gap-3">
            {isOwnProfile ? (
              <Button asChild className="flex-1 bg-blue-600 hover:bg-blue-700 text-white">
                <Link href="/profile" className="flex items-center gap-2">
                  <Settings className="w-4 h-4" />
                  Edit Profile
                </Link>
              </Button>
            ) : (
              <Button
                onClick={handleStartChat}
                disabled={isStartingChat}
                className="flex-1 bg-blue-600 hover:bg-blue-700 text-white flex items-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                {isStartingChat ? "Starting Chat..." : existingChatId ? "Continue Chat" : "Start Chat"}
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Additional Info Card */}
      <Card className="shadow-xl border-0 bg-white/80 backdrop-blur-sm dark:bg-gray-900/80">
        <CardHeader>
          <CardTitle className="text-lg text-gray-900 dark:text-white">Profile Information</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-gray-600 dark:text-gray-300">Status</span>
              <Badge
                variant="secondary"
                className="bg-green-100 text-green-700 dark:bg-green-900/20 dark:text-green-400"
              >
                Online
              </Badge>
            </div>
            <div className="flex items-center justify-between">
              <span className="text-gray-600 dark:text-gray-300">Profile Updated</span>
              <span className="text-gray-900 dark:text-white text-sm">
                {new Date(profile.updated_at).toLocaleDateString()}
              </span>
            </div>
            {!isOwnProfile && (
              <div className="flex items-center justify-between">
                <span className="text-gray-600 dark:text-gray-300">Chat Status</span>
                <Badge variant={existingChatId ? "default" : "secondary"}>
                  {existingChatId ? "Connected" : "Not Connected"}
                </Badge>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
