import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ChatInterface } from "@/components/chat-interface"

export default async function ChatPage() {
  const supabase = await createClient()

  const {
    data: { user },
    error,
  } = await supabase.auth.getUser()

  if (error || !user) {
    redirect("/auth/login")
  }

  // Get user's profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Get user's chats with other user profiles
  const { data: chats } = await supabase
    .from("chats")
    .select(
      `
      id,
      user1_id,
      user2_id,
      updated_at,
      user1:profiles!chats_user1_id_fkey(id, display_name, avatar_url),
      user2:profiles!chats_user2_id_fkey(id, display_name, avatar_url)
    `,
    )
    .or(`user1_id.eq.${user.id},user2_id.eq.${user.id}`)
    .order("updated_at", { ascending: false })

  // Get all users for starting new chats
  const { data: allUsers } = await supabase.from("profiles").select("id, display_name, avatar_url").neq("id", user.id)

  return <ChatInterface currentUser={user} currentProfile={profile} chats={chats || []} allUsers={allUsers || []} />
}
